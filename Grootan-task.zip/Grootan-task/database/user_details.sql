-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2021 at 11:58 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health_monitoring`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `email_id` varchar(35) NOT NULL,
  `age` int(12) NOT NULL,
  `password` varchar(16) NOT NULL,
  `created_date` date NOT NULL,
  `is_admin` int(11) NOT NULL,
  `mobile_no` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `user_name`, `email_id`, `age`, `password`, `created_date`, `is_admin`, `mobile_no`) VALUES
(7, 'Ajay', 'ajay@gmail.com', 23, 'ajay23', '0000-00-00', 0, 9876543211),
(8, 'Banu', 'banu@gmail.com', 23, 'banu23', '0000-00-00', 0, 9876543221),
(9, 'Cabir', 'cabir@gmail.com', 24, 'cabir24', '0000-00-00', 0, 9876543213),
(10, 'Dhanu', 'dhanu@gmal.com', 24, 'dhanu24', '0000-00-00', 0, 9876543213),
(11, 'Elakiya', 'elakiya@gmal.com', 24, 'elakiya24', '0000-00-00', 0, 9876543124),
(12, 'Fahim', 'fahim@gmail.com', 25, 'fahim25', '0000-00-00', 0, 9876543215),
(13, 'Gabi', 'gabi@gmail.com', 25, 'gabi25', '0000-00-00', 0, 9876543216),
(14, 'Habin', 'habin@gmail.com', 23, 'habi23', '0000-00-00', 0, 9876543216),
(15, 'Ishu', 'ishu@gmail.com', 24, 'ishu24', '0000-00-00', 0, 9876543217),
(16, 'Jamu', 'jamu@gmail.com', 23, 'jamu23', '0000-00-00', 0, 9876543299),
(17, 'Kamini', 'kamini@gmail.com', 23, 'kamini23', '0000-00-00', 0, 9987654321),
(18, 'Lahir', 'lahir@gmail.com', 24, 'lahir24', '0000-00-00', 0, 9987654322),
(19, 'Mani', 'mani@gmailcom', 23, 'mani23', '0000-00-00', 0, 9887654321),
(20, 'Narun', 'narun@gmail.com', 23, 'narun23', '0000-00-00', 0, 9877654321),
(21, 'Osaka', 'osaka@gmail.com', 24, 'osaka24', '0000-00-00', 0, 9876654321),
(22, 'Pavan', 'pavan@gmail.com', 23, 'pavan23', '0000-00-00', 0, 9875654321),
(23, 'Queen', 'queen@gmail.com', 23, 'queen23', '0000-00-00', 0, 9876543211),
(24, 'Ravi', 'ravi@gmail.com', 23, 'ravi23', '0000-00-00', 0, 9988765432),
(25, 'Sabin', 'sabin@gmail.com', 23, 'sabin23', '0000-00-00', 0, 9876543219),
(26, 'Tami', 'tamil@gmail.com', 23, 'tamil23', '0000-00-00', 0, 9876553211),
(27, 'Uvan', 'uvan@gmail.com', 23, 'uvan23', '0000-00-00', 0, 9877543213),
(28, 'Varun', 'varun@gmail.com', 23, 'varun23', '0000-00-00', 0, 97765432254),
(29, 'Wamo', 'wamo@gmail.com', 23, 'wamu23', '0000-00-00', 0, 9878654326),
(30, 'Xami', 'xami@gmail.com', 23, 'xami23', '0000-00-00', 0, 9875543211),
(31, 'Yalini', 'yalini@gmail.com', 23, 'yalini23', '0000-00-00', 0, 9876627821),
(32, 'Zamir', 'zamir@gmail.com', 23, 'zamir23', '0000-00-00', 0, 9876565432),
(33, 'Zomu', 'zomu@gmail.com', 24, 'zomu24', '0000-00-00', 0, 9876353211),
(34, 'Zenkins', 'zenkins@gmail.com', 23, 'zenkins23', '0000-00-00', 0, 9876567211),
(35, 'Yuvin', 'yuvin@gmail.com', 23, 'yuvin23', '0000-00-00', 0, 9834343211),
(36, 'admin', 'admin@gmail.com', 0, 'admin', '0000-00-00', 1, 0),
(37, 'dhanajayan', 'dhananjayandurai@gmail.com', 0, 'dhanan2000', '0000-00-00', 1, 9842195965);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
