/*
Template Name: Admin Pro Admin
Author: Wrappixel
Email: niravjoshi87@gmail.com
File: js
*/
$(function () {
    "use strict";
    // ============================================================== 
    // Newsletter
    // ============================================================== 

    var sparklineLogin = function () {
        $('#sparklinedash').sparkline([0, 5, 6, 10, 9, 12, 4, 9], {
            type: 'bar',
            height: '30',
            barWidth: '4',
            resize: true,
            barSpacing: '5',
            barColor: '#7ace4c'
        });
        $('#sparklinedash2').sparkline([0, 5, 6, 10, 9, 12, 4, 9], {
            type: 'bar',
            height: '30',
            barWidth: '4',
            resize: true,
            barSpacing: '5',
            barColor: '#7460ee'
        });
        $('#sparklinedash3').sparkline([0, 5, 6, 10, 9, 12, 4, 9], {
            type: 'bar',
            height: '30',
            barWidth: '4',
            resize: true,
            barSpacing: '5',
            barColor: '#11a0f8'
        });
        $('#sparklinedash4').sparkline([0, 5, 6, 10, 9, 12, 4, 9], {
            type: 'bar',
            height: '30',
            barWidth: '4',
            resize: true,
            barSpacing: '5',
            barColor: '#f33155'
        });
    }
    var sparkResize;
    $(window).on("resize", function (e) {
        clearTimeout(sparkResize);
        sparkResize = setTimeout(sparklineLogin, 500);
    });
    sparklineLogin();
});






usernames = document.getElementById("user_name").value.split(',')
userbps = document.getElementById("user_bp").value.split(',')
userbts = document.getElementById("user_bt").value.split(',')
userpuls = document.getElementById("user_pulse").value.split(',')
userresp = document.getElementById("user_resp").value.split(',')
usergluc = document.getElementById("user_gluc").value.split(',')
useros = document.getElementById("user_os").value.split(',')
userecg = document.getElementById("user_ecg").value.split(',')
var barChartData = {
  labels: usernames,
  datasets:[
    {
          label: "Body Temperature",
          backgroundColor: "springgreen",
          data: userbts
    },
    {
          label: "Blood Pressure",
          backgroundColor: "royalblue",
          data: userbps
    },
    {
          label: "Pulse",
          backgroundColor: "darkgrey",
          data: userpuls
    },
    {
          label: "Respiration",
          backgroundColor: "deepskyblue",
          data: userresp
    },
    {
          label: "Glucose",
          backgroundColor: "indianred",
          data: usergluc
    },
    {
          label: "Oxygen Saturation",
          backgroundColor: "plum",
          data: useros
    },
    {
          label: "ElectroCardiogram",
          backgroundColor: "pink",
          data: userecg
    }
  ]
};


var chartOptions = {
  responsive: true,
  legend: {
    display: false,
    position: "top"
  },
  title: {
    display: false,
    text: "Chart.js Bar Chart"
  },
  scales: {
    xAxes: [{
      ticks:{
      fontSize: 16
    }
    }],                          
    yAxes: [{
        gridLines: {
            color: "rgba(0, 0, 0, 0)",
        }, ticks: {
            beginAtZero: true
        }  
    }]
    }
}

window.onload = function() {
  var ctx = document.getElementById("employeessChart").getContext("2d");
  window.myBar = new Chart(ctx, {
    type: "bar",
    data: barChartData,
    options: chartOptions
  });
};
